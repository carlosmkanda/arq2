/***********************************************************/
/*                                                         */
/*  Filename : general.h                                   */
/*                                                         */
/*  Author   : Frederic Bergeron (91 485 12)               */
/*                                                         */
/*  Date     : 1996/09/26                                  */
/*                                                         */
/***********************************************************/


#include <stdio.h>
#include <stdlib.h>

#define 	TRUE	1
#define		FALSE	0
